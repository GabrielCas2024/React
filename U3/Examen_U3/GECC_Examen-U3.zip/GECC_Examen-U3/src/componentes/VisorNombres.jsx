import { useState } from "react";
import { Input } from "./Input";
//datos_api = Array con los datos en formato json

export function VisorNombres({ datos_api }) {

    //Estados que cogen los datos del input
    const [nombre, setNombre] = useState("");

    //Se filtran los datos segun la variable "nombre"
    const datos_filtrados = datos_api.filter((user) => {
        return user.includes(nombre);
    });

    //Variable "datos_html" contiene los datos mapeados y los guarda con un parrafo para imprimirlo
    const datos_html = datos_filtrados.map((user) => {
        return (
            <div>
                <p>Nombre:{user.name},{user.username} Email:{user.email}  phone:{user.phone} web:{user.website}</p>
            </div>
        )
    })

    return (
        <div>
            <div>
                <Input nombre={nombre} setNombre={setNombre}></Input>
            </div>
            <div>
                {datos_html}
            </div>
        </div>
    )
}