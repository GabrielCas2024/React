export async function ObtenerDatos({url}){
    const response = await fetch(url);
    const datos = await response.json();
    return datos;
}
export default ObtenerDatos;