export function Input({nombre, setNombre}) {
    return (
        <>
        <p>Ingresa el Nombre a filtrar</p>
        <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} />
        </>
    )
}