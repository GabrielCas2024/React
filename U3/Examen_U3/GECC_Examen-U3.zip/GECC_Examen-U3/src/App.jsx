import { useEffect } from 'react'
import './App.css'
import ObtenerDatos from './componentes/ObtenerDatos';
import { VisorNombres } from './componentes/VisorNombres';

//Variable que contiene la url
const url = "https://jsonplaceholder.typicode.com/users";

//Array vacio que contendra todos los datos version json
let datos_api = [];


function App() {
  useEffect(() => {
    datos_api = async () => {
      datos_json = await ObtenerDatos(url);
      return datos_json;
    }
  }, [])

  return (
    <>
      <section>
        <VisorNombres datos_api={datos_api}></VisorNombres>
      </section>
    </>
  )
}

export default App
